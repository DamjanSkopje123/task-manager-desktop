const { autoUpdater } = require('electron-updater');
const { app, dialog, BrowserWindow, ipcMain } = require('electron');
const log = require('electron-log');

// Configure logging
log.transports.file.level = 'info';
autoUpdater.logger = log;

class UpdateManager {
    constructor(mainWindow) {
        this.mainWindow = mainWindow;
        this.setupAutoUpdater();
    }

    setupAutoUpdater() {
        // Configure auto updater
        autoUpdater.autoDownload = false;
        autoUpdater.autoInstallOnAppQuit = true;

        // Check for updates on startup
        this.checkForUpdates();

        // Set up event listeners
        autoUpdater.on('checking-for-update', () => {
            this.sendStatusToWindow('Checking for updates...');
        });

        autoUpdater.on('update-available', (info) => {
            this.sendStatusToWindow('Update available!');
            this.showUpdateDialog(info);
        });

        autoUpdater.on('update-not-available', (info) => {
            this.sendStatusToWindow('No updates available.');
        });

        autoUpdater.on('error', (err) => {
            this.sendStatusToWindow('Error in auto-updater: ' + err.message);
            log.error('Auto updater error:', err);
        });

        autoUpdater.on('download-progress', (progressObj) => {
            let log_message = "Download speed: " + progressObj.bytesPerSecond;
            log_message = log_message + ' - Downloaded ' + progressObj.percent + '%';
            log_message = log_message + ' (' + progressObj.transferred + "/" + progressObj.total + ')';
            this.sendStatusToWindow(log_message);
        });

        autoUpdater.on('update-downloaded', (info) => {
            this.sendStatusToWindow('Update downloaded; will install on quit');
            this.showInstallDialog();
        });

        // Handle IPC messages from renderer
        ipcMain.handle('check-for-updates', () => {
            this.checkForUpdates();
        });

        ipcMain.handle('download-update', () => {
            autoUpdater.downloadUpdate();
        });

        ipcMain.handle('install-update', () => {
            autoUpdater.quitAndInstall();
        });
    }

    checkForUpdates() {
        log.info('Checking for updates...');
        autoUpdater.checkForUpdates();
    }

    sendStatusToWindow(text) {
        log.info(text);
        if (this.mainWindow) {
            this.mainWindow.webContents.send('update-status', text);
        }
    }

    showUpdateDialog(info) {
        const options = {
            type: 'info',
            title: 'Update Available',
            message: 'A new version of Task Manager Desktop is available!',
            detail: `Version ${info.version} is ready to download.\n\nWhat's new:\n• Bug fixes and improvements\n• Enhanced performance\n• New features`,
            buttons: ['Download Now', 'Later', 'Skip This Version'],
            defaultId: 0,
            cancelId: 1
        };

        dialog.showMessageBox(this.mainWindow, options).then((result) => {
            if (result.response === 0) {
                // Download update
                autoUpdater.downloadUpdate();
                this.sendStatusToWindow('Downloading update...');
            } else if (result.response === 2) {
                // Skip this version
                autoUpdater.setFeedURL({
                    provider: 'github',
                    owner: 'your-github-username',
                    repo: 'task-manager-desktop',
                    private: false
                });
            }
        });
    }

    showInstallDialog() {
        const options = {
            type: 'info',
            title: 'Update Ready',
            message: 'Update downloaded successfully!',
            detail: 'The update is ready to install. The application will restart automatically.',
            buttons: ['Install Now', 'Install Later'],
            defaultId: 0,
            cancelId: 1
        };

        dialog.showMessageBox(this.mainWindow, options).then((result) => {
            if (result.response === 0) {
                // Install update
                autoUpdater.quitAndInstall();
            }
        });
    }
}

module.exports = UpdateManager; 