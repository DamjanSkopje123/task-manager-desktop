const { ipcRenderer } = require('electron');

class TaskManager {
    constructor() {
        this.tasks = [];
        this.currentView = 'dashboard';
        this.editingTask = null;
        this.init();
    }

    async init() {
        await this.loadTasks();
        this.setupEventListeners();
        this.updateUI();
        this.setupTheme();
        this.setupUpdateListeners();
    }

    async loadTasks() {
        try {
            this.tasks = await ipcRenderer.invoke('get-tasks');
            this.updateStats();
        } catch (error) {
            console.error('Error loading tasks:', error);
            this.showError('Failed to load tasks. Please restart the application.');
        }
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const view = e.currentTarget.dataset.view;
                this.switchView(view);
            });
        });

        // Add task button
        document.getElementById('addTaskBtn').addEventListener('click', () => {
            this.openTaskModal();
        });

        // Quick action buttons
        document.querySelectorAll('.quick-action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleQuickAction(action);
            });
        });

        // Task modal
        document.getElementById('taskForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveTask();
        });

        document.getElementById('closeModal').addEventListener('click', () => {
            this.closeTaskModal();
        });

        document.getElementById('cancelTask').addEventListener('click', () => {
            this.closeTaskModal();
        });

        // Confirmation modal
        document.getElementById('closeConfirmModal').addEventListener('click', () => {
            this.closeConfirmModal();
        });

        document.getElementById('cancelConfirm').addEventListener('click', () => {
            this.closeConfirmModal();
        });

        document.getElementById('confirmAction').addEventListener('click', () => {
            this.executeConfirmedAction();
        });

        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', () => {
            this.toggleTheme();
        });

        // Search and filters
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterTasks();
        });

        document.getElementById('priorityFilter').addEventListener('change', () => {
            this.filterTasks();
        });

        document.getElementById('statusFilter').addEventListener('change', () => {
            this.filterTasks();
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 'n':
                        e.preventDefault();
                        this.openTaskModal();
                        break;
                    case 's':
                        e.preventDefault();
                        this.saveTask();
                        break;
                }
            }
        });

        // IPC listeners
        ipcRenderer.on('new-task', () => {
            this.openTaskModal();
        });

        ipcRenderer.on('export-tasks', () => {
            this.exportTasks();
        });

        ipcRenderer.on('open-preferences', () => {
            this.openPreferences();
        });
    }

    setupUpdateListeners() {
        // Listen for update status messages
        ipcRenderer.on('update-status', (event, message) => {
            this.showUpdateStatus(message);
        });
    }

    showUpdateStatus(message) {
        // Create or update status notification
        let statusDiv = document.getElementById('updateStatus');
        if (!statusDiv) {
            statusDiv = document.createElement('div');
            statusDiv.id = 'updateStatus';
            statusDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #4CAF50;
                color: white;
                padding: 10px 20px;
                border-radius: 5px;
                z-index: 10000;
                box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            `;
            document.body.appendChild(statusDiv);
        }
        
        statusDiv.textContent = message;
        statusDiv.style.display = 'block';
        
        // Hide after 3 seconds
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }

    showError(message) {
        // Create error notification
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: #f44336;
            color: white;
            padding: 15px 25px;
            border-radius: 5px;
            z-index: 10000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        `;
        errorDiv.textContent = message;
        document.body.appendChild(errorDiv);
        
        // Hide after 5 seconds
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }

    switchView(view) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-view="${view}"]`).classList.add('active');

        // Update views
        document.querySelectorAll('.view').forEach(v => {
            v.classList.remove('active');
        });
        document.getElementById(`${view}View`).classList.add('active');

        // Update header
        this.updateHeader(view);

        this.currentView = view;
        this.updateUI();
    }

    updateHeader(view) {
        const titles = {
            dashboard: 'Dashboard',
            tasks: 'All Tasks',
            pending: 'Pending Tasks',
            completed: 'Completed Tasks',
            overdue: 'Overdue Tasks'
        };

        const subtitles = {
            dashboard: 'Manage your tasks efficiently',
            tasks: 'View and manage all your tasks',
            pending: 'Tasks waiting to be started',
            completed: 'Successfully completed tasks',
            overdue: 'Tasks past their due date'
        };

        document.getElementById('pageTitle').textContent = titles[view];
        document.getElementById('pageSubtitle').textContent = subtitles[view];
    }

    updateUI() {
        this.updateStats();
        this.renderTasks();
    }

    updateStats() {
        const pending = this.tasks.filter(task => task.status === 'pending').length;
        const completed = this.tasks.filter(task => task.status === 'completed').length;
        const overdue = this.tasks.filter(task => this.isOverdue(task)).length;
        const total = this.tasks.length;

        document.getElementById('pendingCount').textContent = pending;
        document.getElementById('completedCount').textContent = completed;
        document.getElementById('overdueCount').textContent = overdue;
        document.getElementById('totalCount').textContent = total;
    }

    renderTasks() {
        const recentTasks = this.tasks
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 5);

        this.renderTaskList('recentTasks', recentTasks);
        this.renderTaskList('tasksList', this.tasks);
        this.renderTaskList('pendingTasksList', this.tasks.filter(task => task.status === 'pending'));
        this.renderTaskList('completedTasksList', this.tasks.filter(task => task.status === 'completed'));
        this.renderTaskList('overdueTasksList', this.tasks.filter(task => this.isOverdue(task)));
    }

    renderTaskList(containerId, tasks) {
        const container = document.getElementById(containerId);
        if (!container) return;

        if (tasks.length === 0) {
            container.innerHTML = '<div class="empty-state">No tasks found</div>';
            return;
        }

        container.innerHTML = tasks.map(task => this.createTaskHTML(task)).join('');
    }

    createTaskHTML(task) {
        const isOverdue = this.isOverdue(task);
        const statusClass = task.status === 'completed' ? 'completed' : '';
        const priorityClass = `priority-${task.priority}`;
        const overdueClass = isOverdue ? 'overdue' : '';

        return `
            <div class="task-item ${statusClass} ${priorityClass} ${overdueClass}" data-task-id="${task.id}">
                <div class="task-header">
                    <div class="task-title">${this.escapeHtml(task.title)}</div>
                    <div class="task-actions">
                        <button class="task-action-btn edit-task" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="task-action-btn delete-task" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="task-meta">
                    <span class="task-priority ${task.priority}">${task.priority}</span>
                    <span class="task-status ${task.status}">${task.status}</span>
                    <span>Due: ${this.formatDate(task.dueDate)}</span>
                </div>
                ${task.description ? `<div class="task-description">${this.escapeHtml(task.description)}</div>` : ''}
            </div>
        `;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    isOverdue(task) {
        if (task.status === 'completed') return false;
        return new Date(task.dueDate) < new Date();
    }

    openTaskModal(task = null) {
        this.editingTask = task;
        const modal = document.getElementById('taskModal');
        const title = document.getElementById('modalTitle');
        const form = document.getElementById('taskForm');

        if (task) {
            title.textContent = 'Edit Task';
            this.populateForm(task);
        } else {
            title.textContent = 'Add New Task';
            form.reset();
            // Set default due date to tomorrow
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            document.getElementById('taskDueDate').value = tomorrow.toISOString().slice(0, 16);
        }

        modal.classList.add('active');
    }

    populateForm(task) {
        document.getElementById('taskTitle').value = task.title;
        document.getElementById('taskPriority').value = task.priority;
        document.getElementById('taskDueDate').value = task.dueDate.slice(0, 16);
        document.getElementById('taskDescription').value = task.description || '';
        document.getElementById('taskStatus').value = task.status;
    }

    closeTaskModal() {
        document.getElementById('taskModal').classList.remove('active');
        this.editingTask = null;
    }

    async saveTask() {
        const formData = {
            title: document.getElementById('taskTitle').value.trim(),
            priority: document.getElementById('taskPriority').value,
            dueDate: document.getElementById('taskDueDate').value,
            description: document.getElementById('taskDescription').value.trim(),
            status: document.getElementById('taskStatus').value
        };

        if (!formData.title) {
            this.showError('Please enter a task title');
            return;
        }

        try {
            if (this.editingTask) {
                await ipcRenderer.invoke('update-task', this.editingTask.id, formData);
            } else {
                await ipcRenderer.invoke('add-task', formData);
            }

            await this.loadTasks();
            this.updateUI();
            this.closeTaskModal();
        } catch (error) {
            console.error('Error saving task:', error);
            this.showError('Error saving task. Please try again.');
        }
    }

    handleQuickAction(action) {
        switch (action) {
            case 'add-task':
                this.openTaskModal();
                break;
            case 'export-tasks':
                this.exportTasks();
                break;
            case 'clear-completed':
                this.showConfirmModal(
                    'Clear Completed Tasks',
                    'Are you sure you want to delete all completed tasks? This action cannot be undone.',
                    () => this.clearCompletedTasks()
                );
                break;
        }
    }

    async exportTasks() {
        try {
            const filePath = await ipcRenderer.invoke('export-tasks');
            if (filePath) {
                this.showUpdateStatus(`Tasks exported successfully to: ${filePath}`);
            }
        } catch (error) {
            console.error('Error exporting tasks:', error);
            this.showError('Error exporting tasks. Please try again.');
        }
    }

    async clearCompletedTasks() {
        try {
            const completedTasks = this.tasks.filter(task => task.status === 'completed');
            for (const task of completedTasks) {
                await ipcRenderer.invoke('delete-task', task.id);
            }
            await this.loadTasks();
            this.updateUI();
            this.showUpdateStatus('Completed tasks cleared successfully');
        } catch (error) {
            console.error('Error clearing completed tasks:', error);
            this.showError('Error clearing completed tasks. Please try again.');
        }
    }

    showConfirmModal(title, message, onConfirm) {
        document.getElementById('modalTitle').textContent = title;
        document.getElementById('confirmMessage').textContent = message;
        document.getElementById('confirmModal').classList.add('active');
        this.pendingConfirmAction = onConfirm;
    }

    closeConfirmModal() {
        document.getElementById('confirmModal').classList.remove('active');
        this.pendingConfirmAction = null;
    }

    executeConfirmedAction() {
        if (this.pendingConfirmAction) {
            this.pendingConfirmAction();
        }
        this.closeConfirmModal();
    }

    filterTasks() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        const priorityFilter = document.getElementById('priorityFilter').value;
        const statusFilter = document.getElementById('statusFilter').value;

        const filteredTasks = this.tasks.filter(task => {
            const matchesSearch = task.title.toLowerCase().includes(searchTerm) ||
                                (task.description && task.description.toLowerCase().includes(searchTerm));
            const matchesPriority = !priorityFilter || task.priority === priorityFilter;
            const matchesStatus = !statusFilter || task.status === statusFilter;

            return matchesSearch && matchesPriority && matchesStatus;
        });

        this.renderTaskList('tasksList', filteredTasks);
    }

    setupTheme() {
        const isDarkMode = localStorage.getItem('darkMode') === 'true';
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
            document.querySelector('#themeToggle i').className = 'fas fa-sun';
        }
    }

    toggleTheme() {
        document.body.classList.toggle('dark-mode');
        const isDarkMode = document.body.classList.contains('dark-mode');
        localStorage.setItem('darkMode', isDarkMode);
        
        const icon = document.querySelector('#themeToggle i');
        icon.className = isDarkMode ? 'fas fa-sun' : 'fas fa-moon';
    }

    openPreferences() {
        // Create preferences modal
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Preferences</h2>
                    <button class="close-btn" onclick="this.closest('.modal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Theme</label>
                        <select id="themeSelect">
                            <option value="light">Light Theme</option>
                            <option value="dark">Dark Theme</option>
                            <option value="auto">Auto (System)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Auto-save interval</label>
                        <select id="autoSaveSelect">
                            <option value="immediate">Immediate</option>
                            <option value="5">5 seconds</option>
                            <option value="10">10 seconds</option>
                            <option value="30">30 seconds</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Notifications</label>
                        <div>
                            <input type="checkbox" id="enableNotifications" checked>
                            <label for="enableNotifications">Enable desktop notifications</label>
                        </div>
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="btn btn-secondary" onclick="this.closest('.modal').remove()">Cancel</button>
                    <button class="btn btn-primary" onclick="this.closest('.modal').remove()">Save</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    // Event delegation for task actions
    setupTaskEventDelegation() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('.edit-task')) {
                const taskId = e.target.closest('.task-item').dataset.taskId;
                const task = this.tasks.find(t => t.id === taskId);
                if (task) {
                    this.openTaskModal(task);
                }
            }

            if (e.target.closest('.delete-task')) {
                const taskId = e.target.closest('.task-item').dataset.taskId;
                const task = this.tasks.find(t => t.id === taskId);
                if (task) {
                    this.showConfirmModal(
                        'Delete Task',
                        `Are you sure you want to delete "${task.title}"? This action cannot be undone.`,
                        () => this.deleteTask(taskId)
                    );
                }
            }
        });
    }

    async deleteTask(taskId) {
        try {
            await ipcRenderer.invoke('delete-task', taskId);
            await this.loadTasks();
            this.updateUI();
            this.showUpdateStatus('Task deleted successfully');
        } catch (error) {
            console.error('Error deleting task:', error);
            this.showError('Error deleting task. Please try again.');
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    const taskManager = new TaskManager();
    taskManager.setupTaskEventDelegation();
}); 