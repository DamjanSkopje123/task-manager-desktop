/**
 * @fileoverview Application configuration and constants
 * @description Centralized configuration for the Task Manager Desktop application
 */

const path = require('path');
const { app } = require('electron');

/**
 * Application configuration object
 * @type {Object}
 */
const config = {
  // App metadata
  app: {
    name: 'Task Manager Desktop',
    version: '1.0.0',
    description: 'Professional Desktop Task Management Application',
    author: 'Your Company',
    homepage: 'https://github.com/your-username/task-manager-desktop'
  },

  // File paths
  paths: {
    userData: app.getPath('userData'),
    logs: path.join(app.getPath('userData'), 'logs'),
    data: path.join(app.getPath('userData'), 'data'),
    temp: path.join(app.getPath('temp'), 'task-manager-desktop')
  },

  // Update configuration
  updates: {
    provider: 'github',
    owner: 'your-github-username',
    repo: 'task-manager-desktop',
    private: false,
    autoDownload: false,
    autoInstallOnAppQuit: true
  },

  // Security settings
  security: {
    encryptionKey: 'your-encryption-key-here', // In production, use environment variable
    algorithm: 'aes-256-gcm',
    saltRounds: 12
  },

  // UI configuration
  ui: {
    defaultTheme: 'system', // 'light', 'dark', 'system'
    animations: {
      duration: 300,
      easing: 'ease-in-out'
    },
    colors: {
      primary: '#667eea',
      secondary: '#764ba2',
      success: '#4CAF50',
      warning: '#FF9800',
      error: '#f44336',
      info: '#2196F3'
    }
  },

  // Task management
  tasks: {
    maxTitleLength: 200,
    maxDescriptionLength: 1000,
    defaultPriority: 'medium',
    priorities: ['low', 'medium', 'high'],
    statuses: ['pending', 'in-progress', 'completed'],
    autoSaveInterval: 5000 // milliseconds
  },

  // Notifications
  notifications: {
    enabled: true,
    reminderInterval: 15, // minutes
    soundEnabled: true
  },

  // Logging
  logging: {
    level: 'info', // 'error', 'warn', 'info', 'debug'
    maxFiles: 10,
    maxSize: 10 * 1024 * 1024 // 10MB
  },

  // Performance
  performance: {
    maxTasksPerPage: 50,
    searchDebounceMs: 300,
    animationFrameRate: 60
  },

  // Development
  development: {
    devTools: false, // Set to true in development
    hotReload: false,
    debugMode: false
  }
};

/**
 * Get configuration value with fallback
 * @param {string} key - Configuration key (dot notation supported)
 * @param {*} defaultValue - Default value if key not found
 * @returns {*} Configuration value
 */
function getConfig(key, defaultValue = null) {
  const keys = key.split('.');
  let value = config;
  
  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = value[k];
    } else {
      return defaultValue;
    }
  }
  
  return value;
}

/**
 * Set configuration value
 * @param {string} key - Configuration key (dot notation supported)
 * @param {*} value - Value to set
 */
function setConfig(key, value) {
  const keys = key.split('.');
  const lastKey = keys.pop();
  let current = config;
  
  for (const k of keys) {
    if (!(k in current)) {
      current[k] = {};
    }
    current = current[k];
  }
  
  current[lastKey] = value;
}

/**
 * Validate configuration
 * @returns {boolean} True if configuration is valid
 */
function validateConfig() {
  const required = [
    'app.name',
    'app.version',
    'paths.userData',
    'updates.provider',
    'security.algorithm'
  ];
  
  for (const key of required) {
    if (!getConfig(key)) {
      console.error(`Missing required configuration: ${key}`);
      return false;
    }
  }
  
  return true;
}

module.exports = {
  config,
  getConfig,
  setConfig,
  validateConfig
}; 