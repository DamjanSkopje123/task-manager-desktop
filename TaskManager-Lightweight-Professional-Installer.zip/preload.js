/**
 * @fileoverview Secure preload script for IPC communication
 * @description Provides safe context bridge between main and renderer processes
 */

const { contextBridge, ipcRenderer } = require('electron');

/**
 * Whitelist of allowed IPC methods for security
 * @type {Array<string>}
 */
const ALLOWED_IPC_METHODS = [
  'get-tasks',
  'save-tasks',
  'add-task',
  'update-task',
  'delete-task',
  'export-tasks',
  'check-for-updates',
  'download-update',
  'install-update',
  'get-app-version',
  'get-user-preferences',
  'set-user-preferences',
  'show-error-dialog',
  'show-info-dialog',
  'open-external-link'
];

/**
 * Validate IPC method name for security
 * @param {string} method - Method name to validate
 * @returns {boolean} True if method is allowed
 */
function isValidIPCMethod(method) {
  return ALLOWED_IPC_METHODS.includes(method);
}

/**
 * Safe IPC wrapper with validation
 * @param {string} method - IPC method name
 * @param {...any} args - Arguments to pass
 * @returns {Promise<any>} IPC response
 */
async function safeIPC(method, ...args) {
  if (!isValidIPCMethod(method)) {
    throw new Error(`Unauthorized IPC method: ${method}`);
  }
  
  try {
    return await ipcRenderer.invoke(method, ...args);
  } catch (error) {
    console.error(`IPC error in ${method}:`, error);
    throw error;
  }
}

/**
 * Expose secure APIs to renderer process
 */
contextBridge.exposeInMainWorld('electronAPI', {
  // Task management
  tasks: {
    /**
     * Get all tasks
     * @returns {Promise<Array>} Array of tasks
     */
    getAll: () => safeIPC('get-tasks'),
    
    /**
     * Save tasks
     * @param {Array} tasks - Tasks to save
     * @returns {Promise<boolean>} Success status
     */
    save: (tasks) => safeIPC('save-tasks', tasks),
    
    /**
     * Add new task
     * @param {Object} task - Task object
     * @returns {Promise<Object>} Created task
     */
    add: (task) => safeIPC('add-task', task),
    
    /**
     * Update existing task
     * @param {string} taskId - Task ID
     * @param {Object} updates - Updates to apply
     * @returns {Promise<Object>} Updated task
     */
    update: (taskId, updates) => safeIPC('update-task', taskId, updates),
    
    /**
     * Delete task
     * @param {string} taskId - Task ID
     * @returns {Promise<boolean>} Success status
     */
    delete: (taskId) => safeIPC('delete-task', taskId),
    
    /**
     * Export tasks to file
     * @returns {Promise<string>} File path
     */
    export: () => safeIPC('export-tasks')
  },

  // Update system
  updates: {
    /**
     * Check for updates
     * @returns {Promise<void>}
     */
    check: () => safeIPC('check-for-updates'),
    
    /**
     * Download update
     * @returns {Promise<void>}
     */
    download: () => safeIPC('download-update'),
    
    /**
     * Install update
     * @returns {Promise<void>}
     */
    install: () => safeIPC('install-update')
  },

  // App information
  app: {
    /**
     * Get app version
     * @returns {Promise<string>} Version string
     */
    getVersion: () => safeIPC('get-app-version'),
    
    /**
     * Get user preferences
     * @returns {Promise<Object>} User preferences
     */
    getPreferences: () => safeIPC('get-user-preferences'),
    
    /**
     * Set user preferences
     * @param {Object} preferences - Preferences to set
     * @returns {Promise<boolean>} Success status
     */
    setPreferences: (preferences) => safeIPC('set-user-preferences', preferences)
  },

  // UI dialogs
  dialogs: {
    /**
     * Show error dialog
     * @param {string} title - Dialog title
     * @param {string} message - Error message
     * @returns {Promise<void>}
     */
    showError: (title, message) => safeIPC('show-error-dialog', title, message),
    
    /**
     * Show info dialog
     * @param {string} title - Dialog title
     * @param {string} message - Info message
     * @returns {Promise<void>}
     */
    showInfo: (title, message) => safeIPC('show-info-dialog', title, message)
  },

  // External links
  external: {
    /**
     * Open external link
     * @param {string} url - URL to open
     * @returns {Promise<void>}
     */
    openLink: (url) => safeIPC('open-external-link', url)
  }
});

/**
 * Listen for update status messages from main process
 */
ipcRenderer.on('update-status', (event, message) => {
  // Dispatch custom event to renderer
  window.dispatchEvent(new CustomEvent('update-status', { detail: message }));
});

/**
 * Listen for error messages from main process
 */
ipcRenderer.on('error-message', (event, message) => {
  // Dispatch custom event to renderer
  window.dispatchEvent(new CustomEvent('error-message', { detail: message }));
});

/**
 * Listen for app quit events
 */
ipcRenderer.on('app-quit', () => {
  // Dispatch custom event to renderer
  window.dispatchEvent(new CustomEvent('app-quit'));
});

// Prevent direct access to Node.js APIs
delete window.require;
delete window.module;
delete window.exports;
delete window.global;
delete window.process; 