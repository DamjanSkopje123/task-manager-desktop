const { app, BrowserWindow, ipcMain, Menu, dialog } = require('electron');
const path = require('path');
const Store = require('electron-store');
const log = require('electron-log');
const UpdateManager = require('./updater');

// Configure logging
log.transports.file.level = 'info';
log.info('Application starting...');

const store = new Store();

let mainWindow;
let updateManager;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    icon: path.join(__dirname, 'assets/icon.png'),
    titleBarStyle: 'default',
    show: false,
    autoHideMenuBar: false
  });

  mainWindow.loadFile('renderer/index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    log.info('Main window displayed');
    
    // Initialize update manager after window is ready
    updateManager = new UpdateManager(mainWindow);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
    log.info('Main window closed');
  });

  // Create professional menu
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'New Task',
          accelerator: 'CmdOrCtrl+N',
          click: () => {
            mainWindow.webContents.send('new-task');
          }
        },
        {
          label: 'Export Tasks',
          click: () => {
            mainWindow.webContents.send('export-tasks');
          }
        },
        { type: 'separator' },
        {
          label: 'Preferences',
          accelerator: 'CmdOrCtrl+,',
          click: () => {
            mainWindow.webContents.send('open-preferences');
          }
        },
        { type: 'separator' },
        {
          label: 'Exit',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectall' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'Check for Updates',
          click: () => {
            if (updateManager) {
              updateManager.checkForUpdates();
            }
          }
        },
        {
          label: 'About Task Manager Desktop',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About Task Manager Desktop',
              message: 'Task Manager Desktop',
              detail: `Version: ${app.getVersion()}\n\nA professional task management application built with Electron.\n\nFeatures:\n• Modern interface with dark/light themes\n• Task management with priorities and due dates\n• Dashboard with statistics\n• Search and filter functionality\n• Export capabilities\n• Auto-updates\n\nBuilt with ❤️ using Electron`
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// App event handlers
app.whenReady().then(() => {
  createWindow();
  log.info('Application ready');
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Handle app quit
app.on('before-quit', () => {
  log.info('Application quitting...');
});

// IPC handlers for task management
ipcMain.handle('get-tasks', () => {
  try {
    const tasks = store.get('tasks', []);
    log.info(`Retrieved ${tasks.length} tasks`);
    return tasks;
  } catch (error) {
    log.error('Error getting tasks:', error);
    return [];
  }
});

ipcMain.handle('save-tasks', (event, tasks) => {
  try {
    store.set('tasks', tasks);
    log.info(`Saved ${tasks.length} tasks`);
    return true;
  } catch (error) {
    log.error('Error saving tasks:', error);
    return false;
  }
});

ipcMain.handle('add-task', (event, task) => {
  try {
    const tasks = store.get('tasks', []);
    task.id = Date.now().toString();
    task.createdAt = new Date().toISOString();
    task.status = 'pending';
    tasks.push(task);
    store.set('tasks', tasks);
    log.info('Task added successfully:', task.title);
    return task;
  } catch (error) {
    log.error('Error adding task:', error);
    return null;
  }
});

ipcMain.handle('update-task', (event, taskId, updates) => {
  try {
    const tasks = store.get('tasks', []);
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex !== -1) {
      tasks[taskIndex] = { ...tasks[taskIndex], ...updates };
      store.set('tasks', tasks);
      log.info('Task updated successfully:', taskId);
      return tasks[taskIndex];
    }
    return null;
  } catch (error) {
    log.error('Error updating task:', error);
    return null;
  }
});

ipcMain.handle('delete-task', (event, taskId) => {
  try {
    const tasks = store.get('tasks', []);
    const filteredTasks = tasks.filter(task => task.id !== taskId);
    store.set('tasks', filteredTasks);
    log.info('Task deleted successfully:', taskId);
    return true;
  } catch (error) {
    log.error('Error deleting task:', error);
    return false;
  }
});

ipcMain.handle('export-tasks', async () => {
  try {
    const tasks = store.get('tasks', []);
    const { filePath } = await dialog.showSaveDialog(mainWindow, {
      defaultPath: 'tasks.json',
      filters: [
        { name: 'JSON Files', extensions: ['json'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    });
    
    if (filePath) {
      const fs = require('fs');
      fs.writeFileSync(filePath, JSON.stringify(tasks, null, 2));
      log.info('Tasks exported successfully to:', filePath);
      return filePath;
    }
    return null;
  } catch (error) {
    log.error('Error exporting tasks:', error);
    return null;
  }
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  log.error('Uncaught Exception:', error);
  dialog.showErrorBox('Error', 'An unexpected error occurred. Please restart the application.');
});

process.on('unhandledRejection', (reason, promise) => {
  log.error('Unhandled Rejection at:', promise, 'reason:', reason);
}); 