# 🚀 Task Manager Desktop

Professional desktop task management application with auto-updates.

## 📥 Download

Click the download button below to get the installer:

[📥 Download TaskManager-Installer.zip](TaskManager-Installer.zip)

## 🎯 Installation

1. **Download** the installer zip file
2. **Extract** the zip file
3. **Run** `install.bat` as administrator
4. **Accept** the terms and conditions
5. **Choose** installation folder
6. **Wait** for dependencies to install
7. **Enjoy** your professional task manager!

## ✨ Features

- ✅ Professional modern interface
- ✅ Dark/light themes
- ✅ Add, edit, delete tasks
- ✅ Search and filter
- ✅ Export functionality
- ✅ Auto-updates
- ✅ Desktop shortcuts

## 🔧 Requirements

- Windows 10 or later
- Node.js (will be checked during installation)
- Internet connection (for dependencies)

## 🚀 Quick Start

After installation, you can run the app from:
- Desktop shortcut
- Start menu
- Direct execution

## 🔄 Auto-Updates

The app automatically checks for updates and notifies you when a new version is available.

---

*Professional Task Manager Desktop - Built with ❤️*
